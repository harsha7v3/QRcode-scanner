//
//  MyCartViewController.swift
//  QRCodeScan
//
//  Created by Mahesh on 31/07/19.
//  Copyright © 2019 test. All rights reserved.
//

import UIKit
import AVFoundation

class MyCartViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    var videoScreenAccess = AVCaptureVideoPreviewLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "MyCard"

       
    }
    

    @IBAction func addButtonTapped(_ sender: Any) {
        
        let videoCaptureSession = AVCaptureSession()
        
        guard let captureDeviceSelect = AVCaptureDevice.default(for: AVMediaType.video) else {
            return
        }
        
        do {
            let input = try AVCaptureDeviceInput(device: captureDeviceSelect)
            
            videoCaptureSession.addInput(input)
        }
        catch
            
        {
            print("not possible")
        }
        
        let videoDeviceOutput = AVCaptureMetadataOutput()
        
        videoCaptureSession.addOutput(videoDeviceOutput)
        
        videoDeviceOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        videoDeviceOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        //so far this session is working in the background. Now from here we are about to show it to the user
        
        videoScreenAccess = AVCaptureVideoPreviewLayer(session: videoCaptureSession)
        
        videoScreenAccess.frame = view.layer.bounds
        
        videoScreenAccess.addSublayer(videoScreenAccess)
        
        videoCaptureSession.startRunning()
        
        
        func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
            
            if metadataObjects.count != 0 {
                
                if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject {
                    
                    if object.type == AVMetadataObject.ObjectType.qr {
                        
                        let showAlert = UIAlertController(title: "QRcode", message: object.stringValue, preferredStyle: .actionSheet)
                        
                        showAlert.addAction(UIAlertAction(title: "Retake", style: .default, handler: nil))
                        
                        showAlert.addAction(UIAlertAction(title: "copy", style: .default, handler: { (nil) in
                            
                            UIPasteboard.general.string = object.stringValue
                            
                        }))
                        
                        
                        present(showAlert, animated: true, completion: nil)
                    }
                    
                }
                
            }
            
        }
        
        
        
    }
   

}
