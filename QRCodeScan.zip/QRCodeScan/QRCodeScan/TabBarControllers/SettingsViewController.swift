//
//  SettingsViewController.swift
//  QRCodeScan
//
//  Created by Mahesh on 31/07/19.
//  Copyright © 2019 test. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    

    

}
